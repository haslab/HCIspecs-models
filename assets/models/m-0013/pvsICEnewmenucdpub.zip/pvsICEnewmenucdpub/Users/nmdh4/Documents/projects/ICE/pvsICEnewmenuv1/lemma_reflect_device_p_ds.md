# Proof for lemma_reflect_device_p_ds
An error occurred while trying to save your proof in PVS.
If the problem persists, please report an issue on [github](https://github.com/nasa/vscode-pvs/issues) or on the [PVS group](https://groups.google.com/g/pvs-group), we will look into it.

## Your proof attempt
Don't panic, your proof attempt for lemma_reflect_device_p_ds is not lost.<br>
VSCode-PVS saved your proof attempt, and you can restore it from the Proof Explorer menu **...** -> **Restore Proof**<br>

If everything else fails, below you can find the complete proof script, which you can paste in the prover terminal to repeat the proof:
```lisp
(skosimp*)(beta)(flatten)(lemma "panlemma1np" ("p" "p!1" "d" "d!1" "st" "st!1"))(beta -1)(split -1)(flatten -1)(lemma "lemma2ippannpdvx" ("p" "p!1" "d" "d!1" "st" "st!1"))(beta -1)(split -1)(flatten -1)(split 8)(flatten 1)(assert)(expand "reflect_device_to_patient" 1)(expand "tick_pan_patient" 1)(replace -11 1)(replace -2 1)(expand "empty_pan_msg" 1)(replace -17 1)(replace -32 1)(beta 1)(expand "update_t_panel" 1)(expand "tick_pan_device" 1)(propax)(flatten 1)(assert)(expand "reflect_device_to_patient" 1)(expand "tick_pan_patient" 1)(replace -11 1)(expand "empty_pan_msg" 1)(replace -3 1)(beta 1)(assert)(replace -17 1)(replace -32 1)(beta 1)(expand "update_t_panel" 1)(expand "tick_pan_device" 1)(propax)(expand "reflect_device_to_patient" 1)(expand "tick_pan_patient" 1)(replace -10 1)(assert)(expand "tick_pan_device" 1)(lift-if 1)(propax)(propax)(propax)(propax)(propax)(lift-if 1)(split 1)(flatten 1)(assert)(flatten 1)(assert)(assert)(lift-if 4)(split 4)(flatten 1)(assert)(flatten 1)(assert)(assert)(assert)(propax)(assert)(propax)(propax)(flatten 1)(assert)(propax)(propax)(propax)(propax)(propax)(propax)(lift-if 2)(split 2)(flatten 1)(assert)(flatten 1)(assert)(assert)(lift-if 4)(split 4)(flatten 1)(assert)(flatten 1)(assert)(assert)(propax)(assert)(propax)(propax)(assert)
```