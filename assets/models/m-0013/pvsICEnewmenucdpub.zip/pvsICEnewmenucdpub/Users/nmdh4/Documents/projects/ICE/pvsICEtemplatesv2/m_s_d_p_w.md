# Proof for m_s_d_p_w
An error occurred while trying to save your proof in PVS.
If the problem persists, please report an issue on [github](https://github.com/nasa/vscode-pvs/issues) or on the [PVS group](https://groups.google.com/g/pvs-group), we will look into it.

## Your proof attempt
Don't panic, your proof attempt for m_s_d_p_w is not lost.<br>
VSCode-PVS saved your proof attempt, and you can restore it from the Proof Explorer menu **...** -> **Restore Proof**<br>

If everything else fails, below you can find the complete proof script, which you can paste in the prover terminal to repeat the proof:
```lisp
(skosimp*)(beta)(flatten)(expand "m_select_d_p_window")(expand "patient_enter_mode")(expand "p_select_d_mode")(expand "per_d_select")(assert)(replace -1 3)(expand "filter_state_patient_station")(split)(grind)(grind)(grind)(grind)(expand "fsp_state")(split)(expand "patient_menu_act" 1)(grind)
```