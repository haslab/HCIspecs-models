# Proof for actlemma2ipenter_coordx
An error occurred while trying to save your proof in PVS.
If the problem persists, please report an issue on [github](https://github.com/nasa/vscode-pvs/issues) or on the [PVS group](https://groups.google.com/g/pvs-group), we will look into it.

## Your proof attempt
Don't panic, your proof attempt for actlemma2ipenter_coordx is not lost.<br>
VSCode-PVS saved your proof attempt, and you can restore it from the Proof Explorer menu **...** -> **Restore Proof**<br>

If everything else fails, below you can find the complete proof script, which you can paste in the prover terminal to repeat the proof:
```lisp
(skosimp*)(beta)(flatten)(split -9)(flatten -1)(assert)(split 12)(flatten 1)(expand "c_d_per_actionx" -1)(flatten -1)(grind)(flatten 1)(expand "c_p_per_actionx" -1)(flatten -1)(expand "coordinator_enter_action" 1)(grind)
```