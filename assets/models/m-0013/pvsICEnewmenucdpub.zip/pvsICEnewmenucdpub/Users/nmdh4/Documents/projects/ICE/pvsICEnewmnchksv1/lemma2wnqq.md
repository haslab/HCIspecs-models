# Proof for lemma2wnqq
An error occurred while trying to save your proof in PVS.
If the problem persists, please report an issue on [github](https://github.com/nasa/vscode-pvs/issues) or on the [PVS group](https://groups.google.com/g/pvs-group), we will look into it.

## Your proof attempt
Don't panic, your proof attempt for lemma2wnqq is not lost.<br>
VSCode-PVS saved your proof attempt, and you can restore it from the Proof Explorer menu **...** -> **Restore Proof**<br>

If everything else fails, below you can find the complete proof script, which you can paste in the prover terminal to repeat the proof:
```lisp
(skosimp*)(beta)(flatten)(lemma "panlemma1np" ("p" "p!1" "d" "d!1" "st" "st!1"))(beta -1)(split -1)(flatten -1)(lemma "panlemma1ipy" ("p" "p!1" "d" "d!1" "st" "st!1"))(beta -1)(split -1)(flatten -1)(lemma "lemma2ippan" ("p" "p!1" "d" "d!1" "st" "st!1"))(beta -1)(split -1)(flatten -1)(split 10)(flatten 1)(assert)(expand "tick_pan_coordinator" 1)(replace -18 1)(beta 1)(lift-if 1)(split 1)(replace -46 1)(replace -45 1)(replace -56 1)(replace -43 1)(replace -42 1)(replace -57 1)(beta 1)(replace -49 1)(replace -48 1)(assert)(flatten -58)(replace -58 1)(assert)
```