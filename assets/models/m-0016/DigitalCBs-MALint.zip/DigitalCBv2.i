# Digital panel version of local control board - v2
# Written by José C. Campos <jose.campos@di.uminho.pt>, based on models developed by Daniel Rodriguez-Hernando <daniel.rodriguez-hernando@irit.fr>

types
  OperatingModeState = {OFF, STBY, OPSTST, OPS, MNT} 
  ToggleBarPosition  = {UP, DOWN}
  AntennaStateV2 = {NoAntenna, DelegatedLLAntenna, ManualLLAntenna}
  AuthTBState = {NAuthLOCKED, NAuthUNLOCKED, AUTH}
  ButtonMode = {Covered, Uncovered, Pressed} 
  ButtonStateV2 = {Locked, Covered, Uncovered, Pressed}
  RcvCmdState = {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived}
  RcvCmdMode = {NOLNK, DTV, LNK, NTL}
  Command = {LNK, NTL, DTV}
  CommandCheck = {NONE, LNK, NTL, DTV}

  
# #########################    
# NTL command automaton
# #########################    
interactor ntlButtonAutomatonV2
  attributes
    [vis] state: ButtonStateV2
  actions
    [vis] liftNTLCover lowerNTLCover pressNTLButton releaseNTLButton
    unlockNTLCommand lockNTLCommand timerTick
  axioms
    # Initial state
    # 
    [] state = Locked

    # Transitions
    # 
    #per(unlockNTLCommand) -> state in {Locked, Covered, Uncovered, Pressed}           
    state in {Locked, Covered} -> [unlockNTLCommand] state' = Covered  # Locked 1, Covered 3
    state = Uncovered -> [unlockNTLCommand] state' = Uncovered         # Uncovered 5
    state = Pressed -> [unlockNTLCommand] state' = Pressed             # Pressed 4

    #per(lockNTLCommand) -> state in {Locked, Covered, Uncovered, Pressed}
    [lockNTLCommand] state' = Locked                                   # Locked 2, Covered 2, Uncovered 3, Pressed 3

    per(liftNTLCover) -> state = Covered
    [liftNTLCover] state' = Uncovered                                  # Covered 1

    per(lowerNTLCover) -> state = Uncovered
    [lowerNTLCover] state' = Covered                                   # Uncovered 1

    per(pressNTLButton) -> state = Uncovered                           
    [pressNTLButton] state' = Pressed                                  # Uncovered 2, 4

    per(releaseNTLButton) -> state = Pressed
    [releaseNTLButton] state' = Uncovered                              # Pressed 1

    per(timerTick) -> state in {Pressed} 
    [timerTick] state' = Pressed                                       # Pressed 2
                          

# #########################    
# NTL auth automaton
# #########################    
interactor NTLAuthAutomaton
  attributes
    state: AuthTBState
    authorization: boolean
    [vis] authTBPosition: ToggleBarPosition
    [vis] authTBLock: boolean
  actions
    [vis] slideAuthTBDown slideAuthTBUp 
    lockAuth unlockAuth 
  axioms
    # Invariants
    # 
    authorization <-> (state = AUTH)
    authTBLock <-> (state = NAuthLOCKED) 
    (authTBPosition = UP) <-> (state in {NAuthLOCKED, NAuthUNLOCKED})
    (authTBPosition = DOWN) <-> (state = AUTH)

    # Initial state
    [] state = NAuthLOCKED 

    # Transitions
    # 
    per(unlockAuth) -> state = NAuthLOCKED
    [unlockAuth] state' = NAuthUNLOCKED                # NAuthLOCKED 1

    #per(lockAuth) -> state in {NAuthLOCKED, NAuthUNLOCKED, AUTH}
    [lockAuth] state' = NAuthLOCKED                    # NAuthLOCKED 2, NAuthUNLOCKED 2, AUTH 2

    per(slideAuthTBDown) -> state = NAuthUNLOCKED
    [slideAuthTBDown] state' = AUTH                    # NAuthUNLOCKED 1

    per(slideAuthTBUp) -> state = AUTH
    [slideAuthTBUp] state' = NAuthUNLOCKED             # AUTH 1

    
  
# #########################    
# DTV Button automaton
# #########################    
interactor DTVButtonAutomatonV2
  attributes
    [vis] state: ButtonStateV2
  actions
    [vis] liftDTVCover lowerDTVCover pressDTVButton releaseDTVButton
    timerTick unlockDTVCommand lockDTVCommand
  axioms
    # Initial state
    # 
    [] state = Locked 

    # Transitions
    # 
    per(unlockDTVCommand) -> state = Locked
    [unlockDTVCommand] state' = Covered                  # Locked 1

    #per(lockDTVCommand) -> state in {Locked, Covered, Uncovered, Pressed}
    [lockDTVCommand] state' = Locked                     # Locked 2, Covered 2, Uncovered 3, Pressed 3
    
    per(liftDTVCover)  -> state = Covered
    [liftDTVCover] state' = Uncovered                    # Covered 1

    per(lowerDTVCover) -> state = Uncovered
    [lowerDTVCover] state' = Covered                     # Uncovered 1

    per(pressDTVButton) -> state = Uncovered 
    [pressDTVButton] state' = Pressed                    # Uncovered 2, 4 - guards and raised events handled in main

    per(releaseDTVButton) -> state = Pressed
    [releaseDTVButton] state' = Uncovered                # Pressed 1 
    
    per(timerTick) -> state = Pressed 
    [timerTick] state' = Pressed                         # Pressed 2


# #########################    
# Received onboard commands panel
# 
# Questions: 
# - Can receive commands before the system is on?! / no init?
# - Can accept when no command?
# #########################    
interactor rcvdOnboardCmdsAutomaton
  attributes
    state: RcvCmdState
    command: CommandCheck
    [vis] DTVindicator, LNKindicator, NTLindicator: boolean 
  actions
    cmdCheck(Command)
    resetReceivedCommand shutDownStation timeOut
  axioms
    # Invariants
    # 
    DTVindicator <-> (state = DTVreceived)
    LNKindicator <-> (state = LNKreceived)
    NTLindicator <-> (state = NTLreceived)

    # Initial state
    # 
    [] state = NoCMDreceived & command = NONE

    # Transitions
    # 
    # Receiving (or re-receiving) LNK
    per(cmdCheck(LNK)) -> state in {NoCMDreceived, LNKreceived}
    state = NoCMDreceived -> [cmdCheck(LNK)] state' = LNKreceived & command' = LNK        # NoCommandReceived 1
    state = LNKreceived -> [cmdCheck(LNK)] state' = LNKreceived & command' = LNK          # LnkReceived 1 

    # From LNK, classifying the received command as DTV or NTL
    per(cmdCheck(NTL)) -> state in {LNKreceived}
    [cmdCheck(NTL)] state' = NTLreceived  & command' = NTL                                # LnkReceived 2

    per(cmdCheck(DTV)) -> state in {LNKreceived}
    [cmdCheck(DTV)] state' = DTVreceived  & command' = DTV                                # LnkReceived 3

    # Timeout back to "no command"
    per(timeOut) -> state in {LNKreceived}
    [timeOut] state' = NoCMDreceived & command' = NONE                                    # LnkReceived 4

    # Reset / shutdown always bring the automaton back to "no command"
    #per(resetReceivedCommand) -> state in {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived} 
    [resetReceivedCommand] state' = NoCMDreceived & command' = NONE        # NoCMDreceived 2, LNKreceived 6, DTVreceived 2, NTLreceived 2

    #per(shutDownStation) -> state in {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived}
    [shutDownStation] state' = NoCMDreceived & command' = NONE             # NoCMDreceived 3, LnkReceived 5, DtvReceived 1, NtlReceived 1


# #########################    
# Single antenna panel
# #########################    
interactor singleAntennaAutomaton
  attributes
    state: AntennaStateV2
    [vis] DLGindicator, LLindicator: boolean
  actions 
    switchLLAntenna initStations shutDownStation
    [vis] pressLLButton pressDLGButton
  axioms
    # Invariants
    # 
    DLGindicator <-> (state = DelegatedLLAntenna)
    LLindicator = state in {DelegatedLLAntenna, ManualLLAntenna}

    # Initial state
    # 
    [] state = NoAntenna

    # Transitions
    # 
    per(initStations) -> state in {NoAntenna}
    [initStations] state' = DelegatedLLAntenna                                        # NoAntenna 1

    per(pressLLButton) -> state in {NoAntenna, ManualLLAntenna} 
    state = NoAntenna -> [pressLLButton] state' = ManualLLAntenna                     # NoAntenna 2 
    state = ManualLLAntenna -> [pressLLButton] state' = NoAntenna                     # ManualLLAntenna 1
    
    per(switchLLAntenna) -> state in {NoAntenna, DelegatedLLAntenna}
    state = NoAntenna -> [switchLLAntenna] state' = DelegatedLLAntenna                 # NoAntenna 3
    state = DelegatedLLAntenna -> [switchLLAntenna] state' = NoAntenna                 # DelegatedLLAntenna 1
    
    #per(shutDownStation) -> state in {NoAntenna, DelegatedLLAntenna, ManualLLAntenna}
    [shutDownStation] state' = NoAntenna                                              # NoAntenna 4, DelegatedLLAntenna 3, ManualLLAntenna 2
    
    per(pressDLGButton) -> state in {DelegatedLLAntenna, ManualLLAntenna}
    state = DelegatedLLAntenna -> [pressDLGButton] state' = ManualLLAntenna           # DelegatedLLAntenna 2
    state = ManualLLAntenna -> [pressDLGButton] state' = DelegatedLLAntenna           # ManualLLAntenna 3


# #########################    
# Operating mode automata
# #########################    
interactor operatingModeAutomatonV2
  attributes
    state: OperatingModeState
    mode:  OperatingModeState                                   # Q. NONE or OFF?!
    # UI feedback / panel status (from entry actions in the chart)
    [vis] modeTBPosition: ToggleBarPosition
    [vis] modeTBLock: boolean
    [vis] STBYindicator, OPSTSTindicator, OPSindicator, MNTindicator: boolean
  actions
    # User interactions
    [vis] slideModeTBDown slideModeTBUp
    [vis] pressSTBY pressOPSTST pressOPS pressMNT
  axioms
    # -----------------------
    # Invariants 
    # -----------------------
    mode = state
    # Indicators
    STBYindicator   <-> (state = STBY)
    OPSTSTindicator <-> (state = OPSTST)
    OPSindicator    <-> (state = OPS)
    MNTindicator    <-> (state = MNT)

    # Toggle bar position and lock follow the current state
    (modeTBPosition = DOWN) <-> (state = OFF)
    (modeTBPosition = UP) <-> (state in {STBY, OPSTST, OPS, MNT})
    modeTBLock <-> (state in {OPSTST, OPS, MNT})

    # -----------------------
    # Initial state
    # -----------------------
    [] state = OFF 

    # -----------------------
    # Transitions
    # -----------------------

    # Power on/off via the toggle bar
    per(slideModeTBUp) -> state = OFF               
    [slideModeTBUp] state' = STBY                   # OFF 1

    per(slideModeTBDown) -> state = STBY              
    [slideModeTBDown] state' = OFF                  # STBY 2

    # Mode selection buttons.
    per(pressOPSTST) -> state in {STBY, OPS, MNT}   
    [pressOPSTST] state' = OPSTST                   # STBY 1, OPS 1, MNT 2

    per(pressOPS) -> state in {STBY, OPSTST, MNT}   
    [pressOPS] state' = OPS                         # STBY 3, OPSTST 2, MNT 1

    per(pressMNT) -> state in {STBY, OPSTST, OPS}   
    [pressMNT] state' = MNT                         # STBY 4, OPSTST 3, OPS 2

    per(pressSTBY) -> state in {OPSTST, OPS, MNT}   
    [pressSTBY] state' = STBY                       # OPSTST 1, OPS 3, MNT 3

   
# #########################
# main
# 
# Questions:
# - What happens in DTV when timeout500ms when mode is not OPS??
# - lock NTL leaving OPS?? it's not unlocked!?
# #########################    
interactor main
  aggregates 
    operatingModeAutomatonV2 via opMode
    singleAntennaAutomaton   via antenna
    rcvdOnboardCmdsAutomaton via rcvdCmds
    DTVButtonAutomatonV2     via dtvButton
    NTLAuthAutomaton         via ntlAuth
    ntlButtonAutomatonV2     via ntlButton
  axioms
    # 
    # Operating mode raised events
    # 
    
    # Antenna
    effect(opMode.slideModeTBUp) <-> effect(antenna.initStations)
    effect(opMode.slideModeTBDown) <-> effect(antenna.shutDownStation) 

    # Received commands
    effect(opMode.slideModeTBDown) <-> effect(rcvdCmds.shutDownStation)
    (opMode.state in {OPSTST, OPS} & (effect(opMode.pressSTBY) | effect(opMode.pressMNT))) <-> effect(rcvdCmds.resetReceivedCommand)

    # DTV command
    (opMode.state in {STBY, OPSTST} & (effect(opMode.pressOPS) | effect(opMode.pressMNT))) <-> effect(dtvButton.unlockDTVCommand)
    (opMode.state in {OPS, MNT} & (effect(opMode.pressOPSTST) | effect(opMode.pressSTBY))) <-> effect(dtvButton.lockDTVCommand)       

    ((dtvButton.state = Uncovered & opMode.mode = OPS & effect(dtvButton.pressDTVButton)) |
     (dtvButton.state = Pressed & opMode.mode = OPS & effect(dtvButton.timerTick))) <-> effect(rcvdCmds.cmdCheck(DTV))

    # NTL Auth 
    effect(opMode.pressOPS) <-> effect(ntlAuth.unlockAuth)
    (opMode.state = OPS & (effect(opMode.pressOPSTST) | effect(opMode.pressMNT) | effect(opMode.pressSTBY)) <-> effect(ntlAuth.lockAuth))

    # NTL command
    ((opMode.state in {STBY, OPSTST, OPS} & effect(opMode.pressMNT)) |
     (ntlAuth.state = NAuthUNLOCKED & effect(ntlAuth.slideAuthTBDown))) <-> effect(ntlButton.unlockNTLCommand)
    ((opMode.state = MNT & (effect(opMode.pressOPS) | effect(opMode.pressOPSTST) | effect(opMode.pressSTBY))) | 
     (opMode.state = OPS & (effect(opMode.pressOPSTST) | effect(opMode.pressSTBY))) | 
     (ntlAuth.state = AUTH & effect(ntlAuth.slideAuthTBUp))) <-> effect(ntlButton.lockNTLCommand)
    
    # NTL command (button)
    ((ntlButton.state = Uncovered & ntlAuth.authorization & effect(ntlButton.pressNTLButton)) |
     (ntlButton.state = Pressed & ntlAuth.authorization & effect(ntlButton.timerTick))) <-> effect(rcvdCmds.cmdCheck(NTL))

    # 
    # Transitions' guards
    # 

    # Operating mode vs Antenna
    per(antenna.pressLLButton) -> (antenna.state = NoAntenna -> opMode.mode != OFF)        
    per(antenna.switchLLAntenna) -> (antenna.state = NoAntenna -> opMode.mode != OFF)

    # Operating mode vs. Received commands
    per(rcvdCmds.cmdCheck(LNK)) -> (rcvdCmds.state=NoCMDreceived -> opMode.state in {OPS, OPSTST}) # What about when in LNKreceived?!
    per(rcvdCmds.cmdCheck(NTL)) -> (opMode.state = OPS)
    per(rcvdCmds.cmdCheck(DTV)) -> (opMode.state = OPS)

    # 
    # Coordination
    # 
    [opMode.slideModeTBDown|opMode.slideModeTBUp|opMode.pressSTBY|opMode.pressOPSTST|opMode.pressOPS|opMode.pressMNT] 
      !effect(antenna.pressLLButton) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.slideAuthTBDown) | effect(ntlAuth.slideAuthTBUp)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton)) 

    [antenna.pressLLButton] 
      !(effect(opMode.slideModeTBDown) | effect(opMode.slideModeTBUp) | effect(opMode.pressSTBY) | effect(opMode.pressOPSTST) | effect(opMode.pressOPS) | effect(opMode.pressMNT)) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.slideAuthTBDown) | effect(ntlAuth.slideAuthTBUp)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [dtvButton.liftDTVCover|dtvButton.lowerDTVCover|dtvButton.pressDTVButton|dtvButton.releaseDTVButton] 
      !(effect(opMode.slideModeTBDown) | effect(opMode.slideModeTBUp) | effect(opMode.pressSTBY) | effect(opMode.pressOPSTST) | effect(opMode.pressOPS) | effect(opMode.pressMNT)) &
      !effect(antenna.pressLLButton) &
      !(effect(ntlAuth.slideAuthTBDown) | effect(ntlAuth.slideAuthTBUp)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [ntlAuth.slideAuthTBDown|ntlAuth.slideAuthTBUp] 
      !(effect(opMode.slideModeTBDown) | effect(opMode.slideModeTBUp) | effect(opMode.pressSTBY) | effect(opMode.pressOPSTST) | effect(opMode.pressOPS) | effect(opMode.pressMNT)) &
      !effect(antenna.pressLLButton) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [ntlButton.liftNTLCover|ntlButton.lowerNTLCover|ntlButton.pressNTLButton|ntlButton.releaseNTLButton] 
      !(effect(opMode.slideModeTBDown) | effect(opMode.slideModeTBUp) | effect(opMode.pressSTBY) | effect(opMode.pressOPSTST) | effect(opMode.pressOPS) | effect(opMode.pressMNT)) &
      !effect(antenna.pressLLButton) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.slideAuthTBDown) | effect(ntlAuth.slideAuthTBUp)) 
 test
  AG(opMode.mode != MNT)
 test
  AG(antenna.state != ManualLLAntenna)
 test
  AG(dtvButton.state != Pressed)
 test # 1 
  AG(opMode.mode=OPS -> !E[(opMode.mode!=OPSTST) U (opMode.mode=STBY)])
 test # 2
  AG(opMode.mode!=STBY -> AX(opMode.mode!=NONE))
 test # 3a
  AG(ntlButton.state=Covered -> !E[(ntlButton.state=Covered) U (ntlButton.state=Pressed)])
 test # 3
  AG(ntlButton.state=Covered -> AX(ntlButton.state!=Pressed))
 test # 3 multi step
  AG(ntlButton.state=Covered -> !E[(ntlButton.state=Covered) U (ntlButton.state=Covered & ntlButton.state=Pressed)])
 test # 3 - liveness
  AG(ntlButton.state=Covered -> EF(ntlButton.state=Pressed))
 test # 3 - liveness witness
  AG(ntlButton.state=Covered -> !EF(ntlButton.state=Pressed))
 test # 3c
  AG(ntlButton.state=Covered -> AX(!effected(ntlButton.pressNTLButton)))
 test # 4 - needed adaptions 
  AG(ntlButton.state=Uncovered -> (ntlAuth.state=AUTH | opMode.mode = MNT))
 test # 5 - needed adaptions 
  AG((ntlAuth.state!=AUTH & EX(ntlAuth.state=AUTH)) -> (opMode.mode = OPS & ntlAuth.state in {NAuthLOCKED, NAuthUNLOCKED}))
 test # 5 - new 
  AG((!ntlAuth.authorization & EX(ntlAuth.authorization)) -> (opMode.mode = OPS & ntlAuth.state in {NAuthLOCKED, NAuthUNLOCKED}))
 test # 6
  AG(dtvButton.state=Covered -> !E[(dtvButton.state=Covered) U (dtvButton.state=Pressed)])
 test # 7
  AG(dtvButton.state=Uncovered -> (opMode.mode in {OPS, MNT}))
