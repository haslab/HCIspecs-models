# Digital panel version of local control board - v1
# Written by José C. Campos <jose.campos@di.uminho.pt>, based on models developed by Daniel Rodriguez-Hernando <daniel.rodriguez-hernando@irit.fr>

types
  OperatingModeState = {OFF, STBY, OPSTST, OPS, MNT} 
  AntennaStateV1 = {NoAntenna, DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas, ManualLLAntenna, ManualRRAntenna, ManualAntennas}
  NTLAuthKeyPosition = {NONE, NotAuthorized, Authorized} 
  AuthKeyState = {NONE, NAUTH, AUTHnotAuthorized, AUTHAuthorized} 
  ButtonStateV1 = {Covered, Uncovered, Pressed} 
  RcvCmdState = {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived}
  RcvCmdMode = {NOLNK, DTV, LNK, NTL}
  Command = {LNK, NTL, DTV}
  CommandCheck = {NONE, LNK, NTL, DTV}


# ######################### 
# NTL command automaton
# ######################### 
interactor ntlButtonAutomatonV1
  attributes
    [vis] state: ButtonStateV1
  actions
    [vis] liftNTLCover lowerNTLCover pressNTLButton releaseNTLButton
    timerTick
  axioms
    # Initial state
    # 
    [] state = Covered

    # Transitions
    # 
    per(liftNTLCover) -> state = Covered                # There should be a guard to guarantee systenm is on?!
    [liftNTLCover] state' = Uncovered                   # Covered 1

    per(lowerNTLCover) -> state = Uncovered  
    [lowerNTLCover] state' = Covered                    # Uncovered 1

    per(pressNTLButton) -> state = Uncovered
    [pressNTLButton] state' = Pressed                   # Uncovered 2, 3 

    per(releaseNTLButton) -> state = Pressed
    [releaseNTLButton] state' = Uncovered               # Pressed 1

    per(timerTick) -> state = Pressed
    [timerTick] state' = Pressed                        # Pressed 2 
                          

# ######################### 
# NTL auth key automaton
# ######################### 
interactor NTLAuthKeyAutomaton
  attributes
    state: AuthKeyState
    authorization: boolean
    [vis] authorizationIndicator: boolean               # C: Could be just authorization!
  actions
    [vis] moveToBottomAuthHandle moveToTopAuthHandle    # Q: Should/could be moveUp/moveDown?
    resetAuthorization                                  # Q: for the always... always could be this internal event triggered by the other panels?
  axioms
    # Invariants
    # 
    authorizationIndicator = authorization 
    authorization <-> (state = AUTHAuthorized)
    
    # Initial state
    # 
    [] state = NONE 

    # Transitions
    per(moveToBottomAuthHandle) -> state in {NONE, NAUTH}
    state = NONE -> [moveToBottomAuthHandle] state' = NAUTH                 # NONE 1
    state = NAUTH -> [moveToBottomAuthHandle] 
                           state' in {AUTHnotAuthorized, AUTHAuthorized}        # NAUTH 1 2 - Depends on operating mode
                           
    per(moveToTopAuthHandle) -> state in {AUTHAuthorized, AUTHnotAuthorized, NAUTH}
    state = AUTHAuthorized -> [moveToTopAuthHandle] state' = NAUTH      # AUTHAuthorized 2
    state = AUTHnotAuthorized -> [moveToTopAuthHandle] state' = NAUTH   # AUTHnotAuthorized 1
    state = NAUTH -> [moveToTopAuthHandle] state' = NONE                    # NAUTH 1

    per(resetAuthorization) -> state = AUTHAuthorized  
    [resetAuthorization] state' = AUTHnotAuthorized                                   # AUTHAuthorized 1 - dependes on operating mode

# #########################    
# DTV Button automaton
# ######################### 
interactor DTVButtonAutomatonV1
  attributes
    [vis] state: ButtonStateV1
  actions
    [vis] liftDTVCover lowerDTVCover pressDTVButton releaseDTVButton
    timerTick
  axioms
    # Initial state
    # 
    [] state = Covered 

    # Transitions
    # 
    per(liftDTVCover)  -> state = Covered              # There should be a guard to guarantee systenm is on?!
    [liftDTVCover] state' = Uncovered                  # Covered 1

    per(lowerDTVCover) -> state = Uncovered
    [lowerDTVCover] state' = Covered                   # Unocevered 1

    per(pressDTVButton) -> state = Uncovered
    [pressDTVButton] state' = Pressed                  # Uncovered 2/3 - guards and raised events in main

    per(releaseDTVButton) -> state = Pressed
    [releaseDTVButton] state' = Uncovered              # Pressed 1
    
    per(timerTick) -> state = Pressed
    [timerTick] state' = Pressed                       # Pressed 2


# #########################    
# Received onboard commands panel
# 
# Questions: 
# - Can receive commands before the system is on?! / no init?
# - Can accept when no command?
# #########################    
interactor rcvdOnboardCmdsAutomaton
  attributes
    state: RcvCmdState
    command: CommandCheck
    [vis] DTVindicator, LNKindicator, NTLindicator: boolean 
  actions
    cmdCheck(Command)
    resetReceivedCommand shutDownStation timeOut
  axioms
    # Invariants
    # 
    DTVindicator <-> (state = DTVreceived)
    LNKindicator <-> (state = LNKreceived)
    NTLindicator <-> (state = NTLreceived)

    # Initial state
    # 
    [] state = NoCMDreceived & command = NONE

    # Transitions
    # 
    # Receiving (or re-receiving) LNK
    per(cmdCheck(LNK)) -> state in {NoCMDreceived, LNKreceived}
    state = NoCMDreceived -> [cmdCheck(LNK)] state' = LNKreceived & command' = LNK        # NoCommandReceived 1
    state = LNKreceived -> [cmdCheck(LNK)] state' = LNKreceived & command' = LNK          # LnkReceived 1 

    # From LNK, classifying the received command as DTV or NTL
    per(cmdCheck(NTL)) -> state in {LNKreceived}
    [cmdCheck(NTL)] state' = NTLreceived  & command' = NTL                                # LnkReceived 2

    per(cmdCheck(DTV)) -> state in {LNKreceived}
    [cmdCheck(DTV)] state' = DTVreceived  & command' = DTV                                # LnkReceived 3

    # Timeout back to "no command"
    per(timeOut) -> state in {LNKreceived}
    [timeOut] state' = NoCMDreceived & command' = NONE                                    # LnkReceived 4

    # Reset / shutdown always bring the automaton back to "no command"
    #per(resetReceivedCommand) -> state in {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived} 
    [resetReceivedCommand] state' = NoCMDreceived & command' = NONE        # NoCMDreceived 2, LNKreceived 6, DTVreceived 2, NTLreceived 2

    #per(shutDownStation) -> state in {NoCMDreceived, LNKreceived, DTVreceived, NTLreceived}
    [shutDownStation] state' = NoCMDreceived & command' = NONE             # NoCMDreceived 3, LnkReceived 5, DtvReceived 1, NtlReceived 1

# #########################    
# Dual antenna panel # Q: There should be a guard to guarantee the system is on?
# #########################    
interactor dualAntennaAutomaton
  attributes
    state: AntennaStateV1
    [vis] DLGindicator, LLindicator, RRindicator: boolean
  actions 
    switchLLAntenna switchRRAntenna initStations shutDownStation
    [vis] pressLLButton pressRRButton pressDLGButton
  axioms
    # Invariants
    # 
    DLGindicator = state in {DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas}
    LLindicator = state in {DelegatedLLAntenna, DelegatedAntennas, ManualLLAntenna, ManualAntennas}
    RRindicator = state in {DelegatedRRAntenna, DelegatedAntennas, ManualRRAntenna, ManualAntennas}

    # Initial state
    # 
    [] state = NoAntenna

    # Transitions
    # 
    per(initStations) -> state = NoAntenna
    [initStations] state' = DelegatedLLAntenna                                  # NoAntenna 1

    per(pressRRButton) -> state in {NoAntenna, DelegatedLLAntenna, DelegatedRRAntenna, ManualLLAntenna, ManualAntennas, ManualRRAntenna} # DelegatedAntennas ??
    state = NoAntenna -> [pressRRButton] state' = ManualRRAntenna                # NoAntenna 2
    state = DelegatedLLAntenna -> [pressRRButton] state' = ManualRRAntenna       # DelegatedLLAntenna 4
    state = ManualLLAntenna -> [pressRRButton] state' = ManualAntennas           # ManualLLAntenna 2
    state = ManualAntennas -> [pressRRButton] state' = ManualLLAntenna           # ManualAntennas 2 
    state = ManualRRAntenna -> [pressRRButton] state' = NoAntenna                # ManualRRAntenna 1        ?! 
        
    per(pressLLButton) -> state in {NoAntenna, DelegatedRRAntenna, ManualLLAntenna, ManualAntennas, ManualRRAntenna} # DelegatedAntennas ??
    state = NoAntenna -> [pressLLButton] state' = ManualLLAntenna                # NoAntenna 3 
    state = DelegatedRRAntenna -> [pressLLButton] state' = ManualLLAntenna       # DelegatedRRAntenna 4
    state = ManualLLAntenna -> [pressLLButton] state' = NoAntenna                # ManualLLAntenna 1        ?!
    state = ManualAntennas -> [pressLLButton] state' = ManualRRAntenna           # ManualAntennas 1 
    state = ManualRRAntenna -> [pressLLButton] state' = ManualAntennas           # ManualRRAntenna 2        
    
    per(switchLLAntenna) -> state in {DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas}
    state = DelegatedLLAntenna -> [switchLLAntenna] state' = NoAntenna           # DelegatedLLAntenna 1     ?!
    state = DelegatedRRAntenna -> [switchLLAntenna] state' = DelegatedAntennas   # DelegatedRRAntenna 2
    state = DelegatedAntennas -> [switchLLAntenna] state' = DelegatedRRAntenna   # DelegatedAntennas 2 

    per(switchRRAntenna) -> state in {DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas}
    state = DelegatedLLAntenna -> [switchRRAntenna] state' = DelegatedAntennas   # DelegatedLLAntenna 2
    state = DelegatedRRAntenna -> [switchRRAntenna] state' = NoAntenna           # DelegatedRRAntenna 1 ?!
    state = DelegatedAntennas -> [switchRRAntenna] state' = DelegatedLLAntenna   # DelegatedAntennas 1 

    per(pressDLGButton) -> state in {DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas, ManualLLAntenna, ManualAntennas, ManualRRAntenna}
    state = DelegatedLLAntenna -> [pressDLGButton] state' = ManualLLAntenna      # DelegatedLLAntenna 3
    state = DelegatedRRAntenna -> [pressDLGButton] state' = ManualRRAntenna      # DelegatedRRAntenna 3
    state = DelegatedAntennas -> [pressDLGButton] state' = ManualAntennas        # DelegatedAntennas 4
    state = ManualLLAntenna -> [pressDLGButton] state' = DelegatedLLAntenna      # ManualLLAntenna 4
    state = ManualAntennas -> [pressDLGButton] state' = DelegatedAntennas        # ManualAntennas 4
    state = ManualRRAntenna -> [pressDLGButton] state' = DelegatedRRAntenna      # ManualRRAntenna 4

    #per(shutDownStation) -> state in {NoAntenna, DelegatedLLAntenna, DelegatedRRAntenna, DelegatedAntennas, ManualLLAntenna, ManualAntennas, ManualRRAntenna}
    [shutDownStation] state' = NoAntenna  
    # NoAntenna 6, DelegatedLLAntenna 5, DelegatedRRAntenna 5, DelegatedAntennas 3, ManualLLAntenna 3, ManualAntennas 3, ManualRRAntenna 3  
    # Q: NoAntenna 6 not in v2?                       

# #########################    
# Operating mode automata
# #########################    
interactor operatingModeAutomatonV1
  attributes
    state: OperatingModeState
    mode: OperatingModeState
    [vis] STBYindicator, OPSTSTindicator, OPSindicator, MNTindicator: boolean
  actions
    [vis] moveToTopOpHandle moveToLeftOpHandle moveToRightOpHandle moveToBottomOpHandle
  axioms
    # Invariants
    # 
    # Mode
    mode = state
    # Indicators
    STBYindicator   <-> (mode = STBY)
    OPSTSTindicator <-> (mode = OPSTST) 
    OPSindicator    <-> (mode = OPS) 
    MNTindicator    <-> (mode = MNT)
    
    # Initial state
    # 
    [] state = OFF

    # Transitions
    # 
    per(moveToTopOpHandle) -> state in {OFF}
    [moveToTopOpHandle] state' = STBY

    per(moveToLeftOpHandle) -> state in {STBY, OPSTST, OPS}
    state = STBY -> [moveToLeftOpHandle] state' = OPSTST
    state = OPSTST -> [moveToLeftOpHandle] state' = OPS
    state = OPS -> [moveToLeftOpHandle] state' = MNT

    per(moveToRightOpHandle) -> state in {OPSTST, OPS, MNT}
    state = MNT -> [moveToRightOpHandle] state' = OPS
    state = OPS -> [moveToRightOpHandle] state' = OPSTST
    state = OPSTST -> [moveToRightOpHandle] state' = STBY

    per(moveToBottomOpHandle) -> state in {STBY}
    [moveToBottomOpHandle] state' = OFF

   
# #########################
# main
# #########################    
interactor main
  aggregates 
    operatingModeAutomatonV1 via opMode
    dualAntennaAutomaton     via antenna
    rcvdOnboardCmdsAutomaton via rcvdCmds
    DTVButtonAutomatonV1     via dtvButton
    NTLAuthKeyAutomaton      via ntlAuth
    ntlButtonAutomatonV1     via ntlButton

  actions 
   tick
  axioms
    # 
    # Operating mode raised events
    # 
    
    # Antenna
    effect(opMode.moveToTopOpHandle) <-> effect(antenna.initStations)
    effect(opMode.moveToBottomOpHandle) <-> effect(antenna.shutDownStation) 

    # Received commands
    effect(opMode.moveToBottomOpHandle) <-> effect(rcvdCmds.shutDownStation)
    ((opMode.mode = OPSTST & effect(opMode.moveToRightOpHandle)) | (opMode.mode=OPS & effect(opMode.moveToLeftOpHandle))) <-> effect(rcvdCmds.resetReceivedCommand)

    # DTV command (button)
    ((dtvButton.state = Uncovered & opMode.mode = OPS & effect(dtvButton.pressDTVButton)) |
     (dtvButton.state = Pressed & opMode.mode = OPS & effect(dtvButton.timerTick))) <-> effect(rcvdCmds.cmdCheck(DTV))

    # Neutralization Authorization
    ntlAuth.state = AUTHAuthorized -> 
             [opMode.moveToTopOpHandle|opMode.moveToLeftOpHandle|opMode.moveToRightOpHandle|opMode.moveToBottomOpHandle] 
                     (opMode.mode' != OPS <-> ntlAuth.state' = AUTHnotAuthorized)
  

    # 
    # Transitions' guards
    # 

    # Operating mode vs. Antenna
    per(antenna.pressLLButton) -> (antenna.state = NoAntenna -> opMode.state != OFF)
    per(antenna.pressRRButton) -> (antenna.state = NoAntenna -> opMode.state != OFF)
    per(antenna.switchLLAntenna) -> (antenna.state = NoAntenna -> opMode.state != OFF)
    per(antenna.switchRRAntenna) -> (antenna.state = NoAntenna -> opMode.state != OFF)
    
    # Operating mode vs. Received commands
    per(rcvdCmds.cmdCheck(LNK)) -> (rcvdCmds.state=NoCMDreceived -> opMode.state in {OPS, OPSTST}) # What about when in LNKreceived?!
    per(rcvdCmds.cmdCheck(NTL)) -> (opMode.state = OPS)
    per(rcvdCmds.cmdCheck(DTV)) -> (opMode.state = OPS)

    # DTV command (button)
    per(dtvButton.timerTick) -> (dtvButton.state = Pressed -> opMode.mode = OPS)    # Q: This is what's in the model, does it make sense?

    # Neutralization Authorization
    (ntlAuth.state = NAUTH & opMode.mode != OPS) -> [ntlAuth.moveToBottomAuthHandle] ntlAuth.state' = AUTHnotAuthorized
    (ntlAuth.state = NAUTH & opMode.mode = OPS) -> [ntlAuth.moveToBottomAuthHandle] ntlAuth.state' = AUTHAuthorized
    

    # 
    # NTL command (button) guards and raised events
    # 
    ((ntlButton.state = Uncovered & ntlAuth.authorization & effect(ntlButton.pressNTLButton)) |
     (ntlButton.state = Pressed & ntlAuth.authorization & effect(ntlButton.timerTick))) <-> effect(rcvdCmds.cmdCheck(NTL))


    # 
    # Coordination
    # 
    [opMode.moveToTopOpHandle|opMode.moveToLeftOpHandle|opMode.moveToRightOpHandle|opMode.moveToBottomOpHandle] 
      !(effect(antenna.pressLLButton) | effect(antenna.pressRRButton)) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.moveToBottomAuthHandle) | effect(ntlAuth.moveToTopAuthHandle)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton)) 

    [antenna.pressLLButton|antenna.pressRRButton] 
      !(effect(opMode.moveToTopOpHandle) | effect(opMode.moveToLeftOpHandle) | effect(opMode.moveToRightOpHandle) | effect(opMode.moveToBottomOpHandle)) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.moveToBottomAuthHandle) | effect(ntlAuth.moveToTopAuthHandle)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [dtvButton.liftDTVCover|dtvButton.lowerDTVCover|dtvButton.pressDTVButton|dtvButton.releaseDTVButton] 
      !(effect(opMode.moveToTopOpHandle) | effect(opMode.moveToLeftOpHandle) | effect(opMode.moveToRightOpHandle) | effect(opMode.moveToBottomOpHandle)) &
      !(effect(antenna.pressLLButton) | effect(antenna.pressRRButton)) &
      !(effect(ntlAuth.moveToBottomAuthHandle) | effect(ntlAuth.moveToTopAuthHandle)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [ntlAuth.moveToBottomAuthHandle|ntlAuth.moveToTopAuthHandle] 
      !(effect(opMode.moveToTopOpHandle) | effect(opMode.moveToLeftOpHandle) | effect(opMode.moveToRightOpHandle) | effect(opMode.moveToBottomOpHandle)) &
      !(effect(antenna.pressLLButton) | effect(antenna.pressRRButton)) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlButton.liftNTLCover) | effect(ntlButton.lowerNTLCover) | effect(ntlButton.pressNTLButton) | effect(ntlButton.releaseNTLButton))

    [ntlButton.liftNTLCover|ntlButton.lowerNTLCover|ntlButton.pressNTLButton|ntlButton.releaseNTLButton] 
      !(effect(opMode.moveToTopOpHandle) | effect(opMode.moveToLeftOpHandle) | effect(opMode.moveToRightOpHandle) | effect(opMode.moveToBottomOpHandle)) &
      !(effect(antenna.pressLLButton) | effect(antenna.pressRRButton)) &
      !(effect(dtvButton.liftDTVCover) | effect(dtvButton.lowerDTVCover) | effect(dtvButton.pressDTVButton) | effect(dtvButton.releaseDTVButton)) &
      !(effect(ntlAuth.moveToBottomAuthHandle) | effect(ntlAuth.moveToTopAuthHandle)) 
 
 test
  AG(opMode.mode != MNT)
 test
  AG(antenna.state != ManualAntennas)
 test
  AG(dtvButton.state != Pressed)
 test # 1 
  AG(opMode.mode=OPS -> !E[(opMode.mode!=OPSTST) U (opMode.mode=STBY)])
 test # 2
  AG(opMode.mode!=STBY -> AX(opMode.mode!=OFF))
 test # 3a
  AG(ntlButton.state=Covered -> !E[(ntlButton.state=Covered) U (ntlButton.state=Pressed)])
 test # 3
  AG(ntlButton.state=Covered -> AX(ntlButton.state!=Pressed))
 test # 3 - liveness
  AG(ntlButton.state=Covered -> EF(ntlButton.state=Pressed))
 test # 3 - liveness witness
  AG(ntlButton.state=Covered -> !EF(ntlButton.state=Pressed))
 test # 3c
  AG(ntlButton.state=Covered -> AX(!effected(ntlButton.pressNTLButton)))
 test # 4
  AG(ntlButton.state=Uncovered -> (ntlAuth.state=AUTHAuthorized | opMode.mode = MNT))
 test # 5
  AG((ntlAuth.state!=AUTHAuthorized & EX(ntlAuth.state=AUTHAuthorized)) -> (opMode.mode = OPS & ntlAuth.state = NAUTH))
 test # 5 - new
  AG((!ntlAuth.authorization & EX(ntlAuth.authorization)) -> (opMode.mode = OPS & ntlAuth.state = NAUTH))
 test # 6
  AG(dtvButton.state=Covered -> !E[(dtvButton.state=Covered) U (dtvButton.state=Pressed)])
 test # 7
  AG(dtvButton.state=Uncovered -> (opMode.mode in {OPS, MNT}))
