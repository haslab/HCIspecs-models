# Alaris GP --- documentation files
HTML files documenting the PVS model of the Alaris GP infusion pump.

* index.html is the top-level file

See [live preview](http://htmlpreview.github.com/?https://github.com/haslab/hcispecs/blob/master/alarisgp-tse/docs/index.html) of the documentation without downloading the files (**Note**: this is an experimental feature in GitHub, sometimes the preview shows a temporary error message "No definition found for Table headers" -- reload the page few times to resolve this temporary error in the preview. If the error persists, please [download the repository](https://github.com/haslab/hcispecs/archive/1.0.zip) on your local machine)

