# Alaris GP --- extended version 

PVS models of the Alaris GP infusion pump from: Verification Templates for the Analysis of User Interface Software Design.

Directory structure
----
This package has the following setup:

* docs/ - this directory contains HTML files documenting the PVS model
* models/ - this directory contains model files, property templates, and proof scripts for re-running the proofs in PVS
